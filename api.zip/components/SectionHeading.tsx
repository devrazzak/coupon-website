import Link from 'next/link';

import { ArrowRight } from 'lucide-react';

export function SectionHeading({
    title,
    subtitle,
    action,
    actionHref = '#',
}: {
    title: string;
    subtitle?: string;
    action?: string;
    actionHref?: string;
}) {
    return (
        <div className="mb-6 flex items-end justify-between gap-4">
            <div>
                <h2 className="font-display text-[20px] font-semibold tracking-tight text-foreground md:text-[24px]">
                    {title}
                </h2>
                {subtitle && <p className="mt-1.5 text-[14px] text-muted-foreground">{subtitle}</p>}
            </div>
            {action && (
                <Link
                    href={actionHref}
                    className="inline-flex shrink-0 items-center gap-1.5 text-[13px] font-bold text-primary transition-colors hover:text-primary-hover"
                >
                    {action}
                    <ArrowRight className="h-3.5 w-3.5" />
                </Link>
            )}
        </div>
    );
}
