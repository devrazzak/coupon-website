import { useInfiniteQuery, useMutation, useQuery, useQueryClient } from '@tanstack/react-query';

import {
    type PublicStoresQuery,
    type StoreCreatePayload,
    type StoreUpdatePayload,
    createStore,
    deleteStore,
    getPublicStores,
    getStores,
    updateStore,
} from '@/utils/api/store';

export function useGetPublicStores(query: PublicStoresQuery = {}) {
    return useQuery({
        queryKey: ['GetPublicStores', query],
        queryFn: () => getPublicStores(query),
        retry: false,
    });
}

export function useInfinitePublicStores(query: PublicStoresQuery = {}) {
    return useInfiniteQuery({
        queryKey: ['GetInfinitePublicStores', query],
        initialPageParam: 1,
        queryFn: ({ pageParam }) => getPublicStores({ ...query, page: pageParam }),
        getNextPageParam: lastPage => {
            const { currentPage, totalCount } = lastPage.data.meta;
            return currentPage * (query.limit || 20) < totalCount ? currentPage + 1 : undefined;
        },
        retry: false,
    });
}

export function useGetStores(page = 1, limit = 10) {
    return useQuery({
        queryKey: ['GetStores', page, limit],
        queryFn: () => getStores(page, limit),
        retry: false,
    });
}

export function useCreateStore() {
    const queryClient = useQueryClient();

    return useMutation({
        mutationKey: ['createStore'],
        mutationFn: (data: StoreCreatePayload) => createStore(data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['GetStores'] });
        },
    });
}

export function useUpdateStore() {
    const queryClient = useQueryClient();

    return useMutation({
        mutationKey: ['updateStore'],
        mutationFn: ({ id, values }: { id: string | number; values: StoreUpdatePayload }) =>
            updateStore(id, values),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['GetStores'] });
        },
    });
}

export function useDeleteStore() {
    const queryClient = useQueryClient();

    return useMutation({
        mutationKey: ['deleteStore'],
        mutationFn: (id: string | number) => deleteStore(id),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['GetStores'] });
        },
    });
}
